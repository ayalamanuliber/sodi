# Pack Completo

Archivo preparado para entrega automática desde SODI.

- Registros: 21151
- Formatos incluidos: CSV y XLSX
- Contacto mínimo por registro: mail o teléfono
- Muchos registros incluyen ambos

Columnas incluidas:
name, rubro, email, phone, whatsapp, best_outreach_number, address, city, province, website, instagram, facebook, linkedin, source, lead_score, lead_tier, contact_channel
